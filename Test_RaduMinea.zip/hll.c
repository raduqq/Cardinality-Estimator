#include <stdio.h>

int main() {
    printf("Test me!\n");
    return 0;
}